// ════════════════════════════════════════════════════════════
//  MA CRM — Node.js + SQLite Backend
//  Version: 1.5 (WhatsApp in the SAME browser via extension — no separate browser)
//  Run: node server.js
//  URL: http://localhost:3000
// ════════════════════════════════════════════════════════════

const express  = require('express');
const sqlite3  = require('sqlite3').verbose();
const path     = require('path');
const fs       = require('fs');
const crypto   = require('crypto');
const zlib     = require('zlib');

// ── .env — GEMINI_API_KEY yahan rakhein, code mein nahi ────────
// Own small reader so it works on every Node version and forgives
// common Windows mistakes: Notepad saving ".env.txt", a browser saving
// the download as "env" or "_env", UTF-8 BOM, quotes, spaces around "=".
const ENV_CANDIDATES = ['.env', '.env.txt', 'env', 'env.txt', '_env', '_env.txt', '.env.example'];
function readEnvFile(file) {
  const out = {};
  let text = fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '');
  for (let line of text.split(/\r?\n/)) {
    line = line.trim();
    if (!line || line.startsWith('#')) continue;
    const m = /^(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*[=:]\s*(.*)$/.exec(line);
    if (!m) continue;
    let v = m[2].trim();
    if (/^(["']).*\1$/.test(v)) v = v.slice(1, -1);
    else v = v.replace(/\s+#.*$/, '').trim();
    out[m[1].toUpperCase()] = v;
  }
  return out;
}
const envInfo = { file: null, fromEnvVar: false, notes: [] };
(function loadEnv() {
  if ((process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || '').trim()) envInfo.fromEnvVar = true;
  for (const name of ENV_CANDIDATES) {
    const file = path.join(__dirname, name);
    if (!fs.existsSync(file) || !fs.statSync(file).isFile()) continue;
    let vars;
    try { vars = readEnvFile(file); } catch (e) { envInfo.notes.push(`${name} read nahi hui: ${e.message}`); continue; }
    const hasKey = !!(vars.GEMINI_API_KEY || vars.GOOGLE_API_KEY);
    if (name === '.env.example' && !hasKey) continue;   // untouched example file
    if (!envInfo.file) {
      envInfo.file = name;
      for (const [k, v] of Object.entries(vars)) {
        const cur = (process.env[k] || '').trim();
        if (!cur) process.env[k] = v;
        else if (/API_KEY$/.test(k) && v && cur !== v) envInfo.notes.push(`Windows/system environment variable ${k} "${name}" wali key se alag hai — environment variable wali use ho rahi hai`);
      }
      if (name !== '.env') envInfo.notes.push(`"${name}" se settings li gayin — behtar hai file ka naam ".env" rakhein`);
    } else if (hasKey) {
      envInfo.notes.push(`"${name}" bhi mili lekin use nahi hui ("${envInfo.file}" pehle mili)`);
    }
  }
})();
const ai = require('./ai-import');
const rapidocr = require('./rapidocr-provider');
const { createExtractionService } = require('./extraction-jobs');
const phoneUtil   = require('./phone');
const waSender    = require('./whatsapp-sender');
const createWaFlow = require('./whatsapp-workflow');
const keyCheck = ai.cleanApiKey(process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || '');
const GEMINI_API_KEY = keyCheck.key;
// ── Backup AI providers (used automatically when the main Gemini key is busy / out of quota) ──
//   GEMINI_API_KEY_2, GEMINI_API_KEY_3 = extra Gemini keys (best: from a DIFFERENT Google account/project)
//   NVIDIA_API_KEY = free key from build.nvidia.com; NVIDIA_MODEL default nvidia/muse-glimmer-30b (reads images)
const GEMINI_KEYS = [GEMINI_API_KEY, ...['GEMINI_API_KEY_2', 'GEMINI_API_KEY_3'].map(n => ai.cleanApiKey(process.env[n] || '').key)]
  .filter((k, i, arr) => k && arr.indexOf(k) === i);
const NVIDIA_API_KEY = String(process.env.NVIDIA_API_KEY || '').replace(/^\uFEFF/, '').trim().replace(/^["']+|["']+$/g, '').split(/\s+/)[0] || '';
const NVIDIA_MODEL = (process.env.NVIDIA_MODEL || 'nvidia/muse-glimmer-30b').trim();
const NVIDIA_BASE_URL = (process.env.NVIDIA_BASE_URL || ai.NVIDIA_BASE_DEFAULT).trim();
const AI_ENABLED = !!(GEMINI_KEYS.length || NVIDIA_API_KEY || rapidocr.RAPIDOCR_ENABLED);
const GEMINI_MODEL   = (process.env.GEMINI_MODEL || 'gemini-3.8-flash').trim().replace(/^models\//, '');
// Backup models used only when the main model is busy (HTTP 503 "high demand").
// Stable (GA) models by default; override in .env with GEMINI_FALLBACK_MODELS=a,b
const GEMINI_FALLBACK_MODELS = String(process.env.GEMINI_FALLBACK_MODELS || 'gemini-3.6-flash,gemini-3.5-flash-lite')
  .split(',').map(m => m.trim().replace(/^models\//, '')).filter(m => m && m !== GEMINI_MODEL);
// Result of the startup key check, shown in the Import modal
let aiHealth = { state: GEMINI_API_KEY ? 'checking' : 'off', message: '' };

const app  = express();
const PORT = Number(process.env.PORT) || 3000;
// Keep the SQLite database and screenshot uploads together on a persistent disk.
const DATA_DIR = path.resolve(process.env.DATA_DIR || __dirname);
fs.mkdirSync(DATA_DIR, { recursive: true });

// APIs are same-origin; never expose unrestricted cross-origin credentials.
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'same-origin');
  if (req.path.startsWith('/api/')) res.setHeader('Cache-Control', 'no-store');
  next();
});
app.use(express.json({ limit: '10mb' }));

// ── GZIP COMPRESSION (built-in zlib, no extra npm package needed) ──────
// public/index.html is ~370 KB of inline HTML/CSS/JS. On fast PC wifi this
// barely registers, but on mobile data + a weaker phone CPU it visibly
// slows down the login → dashboard load. Gzipping text responses typically
// shrinks them 70-80%, which is the single biggest win for mobile speed
// while staying on Render's free plan (no paid tier / extra service needed).
const COMPRESSIBLE = /^(text\/|application\/javascript|application\/json|image\/svg\+xml)/;
app.use((req, res, next) => {
  const acceptEncoding = req.headers['accept-encoding'] || '';
  if (!acceptEncoding.includes('gzip')) return next();

  const originalWrite = res.write.bind(res);
  const originalEnd   = res.end.bind(res);
  let gzip = null;
  let started = false;

  function startGzipIfNeeded() {
    if (started) return;
    started = true;
    const type = String(res.getHeader('Content-Type') || '');
    if (res.headersSent || !COMPRESSIBLE.test(type) || res.getHeader('Content-Encoding')) return;
    res.removeHeader('Content-Length'); // length changes once compressed
    res.setHeader('Content-Encoding', 'gzip');
    res.setHeader('Vary', 'Accept-Encoding');
    gzip = zlib.createGzip();
    gzip.on('data', chunk => originalWrite(chunk));
    gzip.on('end', () => originalEnd());
  }

  res.write = (chunk, ...args) => {
    startGzipIfNeeded();
    if (gzip) { gzip.write(chunk); return true; }
    return originalWrite(chunk, ...args);
  };
  res.end = (chunk, ...args) => {
    startGzipIfNeeded();
    if (gzip) { if (chunk) gzip.write(chunk); gzip.end(); return; }
    return originalEnd(chunk, ...args);
  };
  next();
});

// ── STATIC CACHE HEADERS ─────────────────────────────────────
// Repeat visits (same staff member reopening the app) load instantly
// instead of re-downloading the same files every time.
const STATIC_CACHE = { maxAge: '1d', etag: true };

// Shared phone utility — the review form loads the SAME file the server uses
app.get('/lib/phone.js', (req, res) => res.type('application/javascript').sendFile(path.join(__dirname, 'phone.js')));

// ── REPORT PAGE (must be BEFORE static middleware) ───────────
app.get('/report', (req, res) => {
  const reportPath = path.join(__dirname, 'public', 'report.html');
  if (fs.existsSync(reportPath)) {
    res.sendFile(reportPath);
  } else {
    res.status(404).json({ error: 'report.html nahi mila. public/ folder mein rakho.' });
  }
});

// HTML pages must ALWAYS be revalidated: with the 1-day cache a browser kept showing the OLD CRM page
// after a deploy. (ETag still makes an unchanged page cost almost nothing.) Other static files keep the cache.
app.use(express.static(path.join(__dirname, 'public'), {
  ...STATIC_CACHE,
  setHeaders: (res, file) => { if (/\.html?$/i.test(file)) res.setHeader('Cache-Control', 'no-cache'); },
}));

// ── DATABASE SETUP ──────────────────────────────────────────
// DATABASE_URL set → Supabase Postgres (permanent). Not set → local SQLite file.
const DB = require('./db')({ dataDir: DATA_DIR });
const { dbRun, dbGet, dbAll, t: T } = DB;
console.log('✅ Database engine →', DB.label);

const auth = require('./auth')({ dbRun, dbGet });
// Public access is protected with cookie sessions; turn on private networking explicitly if desired.
if (process.env.CRM_PRIVATE_NETWORK === '1') app.use(auth.network);
app.use(auth.gate);
// Adds a column to an existing database; "already exists" is the normal case and is ignored.
const addColumn = (table, def) => DB.addColumn(table, def).catch(e => console.warn(`⚠ Column "${def}" add nahi hua:`, e.message));

// ── ORIGINAL ORDER SCREENSHOTS (stored byte-for-byte, never resized) ──
// order-screenshots/tmp/<id>      uploaded, order not placed yet (auto-deleted after 24h)
// order-screenshots/orders/<n>/   belongs to order #n — this exact file is sent on WhatsApp
const SS_ROOT = path.join(DATA_DIR, 'order-screenshots');
const SS_TMP  = path.join(SS_ROOT, 'tmp');
fs.mkdirSync(SS_TMP, { recursive: true });
fs.mkdirSync(path.join(SS_ROOT, 'orders'), { recursive: true });

const storage = require('./storage')();
console.log('✅ Screenshot storage →', storage.enabled ? `Supabase bucket "${storage.bucket}" (permanent)` : 'local disk only (set SUPABASE_URL + SUPABASE_SERVICE_KEY for permanent copies)');

const waFlow = createWaFlow({
  dbRun, dbGet, dbAll,
  screenshotRoot: SS_ROOT,
  ensureFile: fileName => storage.ensureLocal(SS_ROOT, fileName),
  gemini: {
    apiKey: GEMINI_API_KEY || GEMINI_KEYS[0] || '',
    apiKeys: GEMINI_KEYS,
    nvidia: NVIDIA_API_KEY ? { apiKey: NVIDIA_API_KEY, model: NVIDIA_MODEL, baseUrl: NVIDIA_BASE_URL } : null,
    models: [GEMINI_MODEL, ...GEMINI_FALLBACK_MODELS],
    language: (process.env.WHATSAPP_MESSAGE_LANGUAGE || 'English').trim(),
    // Message wording comes from whatsapp-message.txt. WHATSAPP_MESSAGE=gemini → let Gemini write it instead.
    mode: /^gemini$/i.test(String(process.env.WHATSAPP_MESSAGE || '').trim()) ? 'gemini' : 'template',
  },
});
const BUSINESS_NAME = (process.env.BUSINESS_NAME || '').trim();

// ── CREATE TABLES ───────────────────────────────────────────
async function initDB() {
  await DB.init();

  await dbRun(`
    CREATE TABLE IF NOT EXISTS users (
      id         ${T.id},
      name       TEXT    NOT NULL,
      email      TEXT    UNIQUE NOT NULL,
      password   TEXT    NOT NULL,
      role       TEXT    DEFAULT 'staff',
      photo      TEXT,
      created_at ${T.ts} DEFAULT CURRENT_TIMESTAMP
    )
  `);

  await dbRun(`
    CREATE TABLE IF NOT EXISTS orders (
      id          ${T.id},
      name        TEXT    NOT NULL,
      phone       TEXT    NOT NULL,
      detail      TEXT    DEFAULT '',
      amount      ${T.real} NOT NULL,
      advance     ${T.real} DEFAULT 0,
      status      TEXT    DEFAULT 'Processing',
      assigned_to INTEGER DEFAULT 1,
      tracking_id TEXT    DEFAULT '',
      date        TEXT    NOT NULL,
      month       INTEGER NOT NULL,
      year        INTEGER NOT NULL,
      created_at  ${T.ts} DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Add tracking_id to existing databases that were created before this column existed
  await addColumn('orders', `tracking_id TEXT DEFAULT ''`);

  // Clients saved without an order ("Save Client Only") + audit trail.
  // Existing orders keep working unchanged: client_id stays NULL and
  // source defaults to 'manual' for every row that already exists.
  await dbRun(`
    CREATE TABLE IF NOT EXISTS clients (
      id         ${T.id},
      name       TEXT    NOT NULL,
      phone      TEXT    DEFAULT '',
      email      TEXT    DEFAULT '',
      address    TEXT    DEFAULT '',
      notes      TEXT    DEFAULT '',
      source     TEXT    DEFAULT 'manual',
      created_at ${T.ts} DEFAULT CURRENT_TIMESTAMP
    )
  `);
  await addColumn('orders', `client_id INTEGER`);
  await addColumn('orders', `source TEXT DEFAULT 'manual'`);

  // WhatsApp order confirmation (only ever written by whatsapp-workflow.js)
  for (const col of [
    `address TEXT DEFAULT ''`,
    `workflow_state TEXT`,          // ORDER_PLACED → WHATSAPP_PENDING → WHATSAPP_OPENED → WHATSAPP_SENT | WHATSAPP_FAILED
    `wa_status TEXT`,               // NULL | pending | processing | sent | failed
    `wa_phone TEXT`,                // normalized number the message goes to
    `wa_snapshot TEXT`,             // order data frozen at Place Order — the message is built from this
    `wa_message TEXT`,
    `wa_message_source TEXT`,       // gemini | standard | manual
    `wa_step TEXT`, `wa_progress TEXT`, `wa_error TEXT`, `wa_error_code TEXT`,
    `wa_parts_sent INTEGER DEFAULT 0`, `wa_attempts INTEGER DEFAULT 0`,
    `wa_started_at ${T.ts}`, `wa_sent_at ${T.ts}`,
  ]) await addColumn('orders', col);

  // Order Placed Date + VPL 3-day reminder. Purely additive: every existing order keeps
  // NULL / 0 in these columns, so no old data is overwritten with a guessed date.
  for (const col of [
    `placed_date TEXT`,                       // YYYY-MM-DD, stamped by the server when the order is placed
    `shipped_date TEXT`,                      // YYYY-MM-DD, stamped when a VPL tracking ID is first saved
    `vpl_reminder_sent INTEGER DEFAULT 0`,    // 0 = NO, 1 = YES
    `vpl_reminder_sent_at ${T.ts}`,
    `vpl_reminder_error TEXT`,                // only set when a send's outcome is unknown (never auto-retried)
  ]) await addColumn('orders', col);

  // ── ORDER OWNERSHIP (Staff isolation) ──
  // Who placed the order. Set ONLY by the server from the logged-in session at creation and
  // never changed by an edit. Older orders keep NULL here and are treated as Admin orders,
  // so they are never shown to Staff (the Staff filter is created_by_user_id = <own id>).
  for (const col of [
    `created_by_user_id INTEGER`,
    `created_by_role TEXT`,          // 'admin' | 'staff'
    `created_by_name TEXT`,          // name at creation time (kept if the staff account is later deleted)
    `updated_at ${T.ts}`,
  ]) await addColumn('orders', col);
  // ── MANUAL DISPATCH MESSAGE (Method 1: WhatsApp click-to-chat) ──
  // Separate from the automatic wa_* columns so the two never overwrite each other.
  // NULL = not opened yet ("Ready to Send" when the data is complete) → 'opened' → 'sent'.
  // 'sent' is ONLY written when a person confirms it; opening a chat proves nothing.
  // Never touches the order status or courier status.
  for (const col of [
    `dispatch_status TEXT`,            // NULL | opened | sent
    `dispatch_phone TEXT`,             // number the chat was opened for (digits, with country code)
    `dispatch_opened_at ${T.ts}`,
    `dispatch_sent_at ${T.ts}`,
    `dispatch_by_user_id INTEGER`,     // who last opened / confirmed
    `dispatch_by_name TEXT`,
  ]) await addColumn('orders', col);
  await dbRun(`CREATE INDEX IF NOT EXISTS idx_orders_created_by ON orders(created_by_user_id)`)
    .catch(e => console.warn('⚠ idx_orders_created_by:', e.message));

  // Per-user profile picture + account status (older databases may be missing these)
  await addColumn('users', `photo TEXT`);
  await addColumn('users', `active INTEGER DEFAULT 1`);

  await dbRun(`
    CREATE TABLE IF NOT EXISTS order_screenshots (
      id            ${T.id},
      order_id      INTEGER NOT NULL,
      position      INTEGER NOT NULL,
      file_name     TEXT    NOT NULL,
      original_name TEXT    DEFAULT '',
      mime          TEXT    NOT NULL,
      bytes         INTEGER NOT NULL,
      sha256        TEXT    NOT NULL,
      created_at    ${T.ts} DEFAULT CURRENT_TIMESTAMP
    )
  `);
  await dbRun(`CREATE INDEX IF NOT EXISTS idx_order_screenshots_order ON order_screenshots(order_id)`);

  await dbRun(`
    CREATE TABLE IF NOT EXISTS settings (
      key   TEXT PRIMARY KEY,
      value TEXT
    )
  `);

  // Hash any passwords left in an older local database. Never ship a default password.
  const oldUsers = await dbAll(`SELECT id, password FROM users`);
  for (const u of oldUsers) {
    if (!auth.isHashed(u.password)) {
      await dbRun(`UPDATE users SET password=? WHERE id=?`, [auth.hashPassword(u.password), u.id]);
    }
  }
  const adminExists = await dbGet(`SELECT id FROM users WHERE role='admin' LIMIT 1`);
  if (!adminExists) {
    const email = (process.env.ADMIN_EMAIL || '').trim();
    const password = process.env.ADMIN_PASSWORD || '';
    if (!/^\S+@\S+\.\S+$/.test(email) || password.length < 12) {
      throw new Error('Set ADMIN_EMAIL and ADMIN_PASSWORD (at least 12 characters) as private hosting environment variables before starting MA CRM.');
    }
    await dbRun(`INSERT INTO users (name, email, password, role) VALUES (?,?,?,?)`,
      [(process.env.ADMIN_NAME || 'CRM Admin').trim(), email, auth.hashPassword(password), 'admin']);
    console.log('✅ Initial admin account created securely');
  }
  await auth.init();
  try { const n = await DB.secure(); if (DB.engine === 'postgres') console.log(`🔒 Row Level Security ON for ${n} tables`); }
  catch (e) { console.warn('⚠ RLS enable nahi hua:', e.message); }
  console.log('✅ Database tables ready');
}

// ════════════════════════════════════════════════════════════
//  🔐 ORDER ACCESS — every order route goes through these.
//  Admin  → every order.
//  Staff  → ONLY rows where created_by_user_id = their own user id.
//  Checked here on the server; the browser is never trusted for this.
// ════════════════════════════════════════════════════════════
const isAdmin = u => !!u && u.role === 'admin';
function canAccessOrder(user, order) {
  if (!user || !order) return false;
  if (isAdmin(user)) return true;
  return user.role === 'staff' && order.created_by_user_id !== null && order.created_by_user_id !== undefined
    && Number(order.created_by_user_id) === Number(user.id);
}
// WHERE fragment that limits an orders query to what this user may see.
function orderScope(user, alias = '') {
  const c = alias ? alias + '.' : '';
  if (isAdmin(user)) return { sql: '1=1', params: [] };
  if (user && user.role === 'staff') return { sql: `${c}created_by_user_id = ?`, params: [user.id] };
  return { sql: '1=0', params: [] };
}
const ORDER_DENIED = { success: false, code: 'forbidden', message: 'Access denied — this order does not belong to your account.' };
// Loads an order the current user may act on. Staff get the same 403 for "not yours" and
// "does not exist", so order IDs belonging to others cannot be probed.
async function orderForUser(user, rawId) {
  const id = Number(rawId);
  if (!Number.isInteger(id) || id <= 0) return { status: 400, body: { success: false, message: 'Invalid order id' } };
  const order = await dbGet(`SELECT * FROM orders WHERE id=?`, [id]);
  if (order && canAccessOrder(user, order)) return { order };
  if (!order && isAdmin(user)) return { status: 404, body: { success: false, code: 'not_found', message: 'Order nahi mila' } };
  return { status: 403, body: ORDER_DENIED };
}
// Route guard for /api/orders/:id/... — puts the checked order on req.order.
const requireOrderAccess = async (req, res, next) => {
  try {
    const r = await orderForUser(req.user, req.params.id);
    if (!r.order) return res.status(r.status).json(r.body);
    req.order = r.order; next();
  } catch (e) { console.error('[order access]', e.message); res.status(500).json({ success: false, message: 'Server error' }); }
};
// Staff-account management (add / edit / disable / delete) is Admin-only. auth.js already blocks
// /api/staff/* for staff at the gate; this second check sits on the routes themselves, so a
// staff account can never create or change accounts even if the gate list is edited later.
const STAFF_ADMIN_ONLY = { success: false, code: 'forbidden', message: 'Only the Admin can add or manage staff accounts.' };
const requireAdmin = (req, res, next) => (isAdmin(req.user) ? next() : res.status(403).json(STAFF_ADMIN_ONLY));
// Ownership stamped on a NEW order — always from the session, never from the request body.
// Same order code the CRM shows everywhere (MA-MMYY-id; month is stored 0-based).
const makeOrderCode = o => `MA-${String(Number(o.month) + 1).padStart(2, '0')}${String(o.year).slice(-2)}-${o.id}`;
const ownerOf = user => ({ id: user.id, role: isAdmin(user) ? 'admin' : 'staff', name: user.name || '' });

// ── PROFILE PICTURES — one per user account, stored on the user row ──
const PHOTO_MAX_CHARS = 3 * 1024 * 1024;   // ≈ 2.2 MB image after base64
// Accepts a real PNG/JPG/WEBP data URL (bytes are checked), or empty = remove photo.
function cleanPhoto(p) {
  if (p === null || p === undefined || p === '') return { ok: true, value: null };
  if (typeof p !== 'string' || p.length > PHOTO_MAX_CHARS) return { ok: false, message: 'Photo 2MB se choti honi chahiye' };
  const m = /^data:image\/(png|jpe?g|webp);base64,([A-Za-z0-9+/=\r\n]+)$/.exec(p.trim());
  if (!m) return { ok: false, message: 'Photo PNG, JPG ya WEBP image honi chahiye' };
  const kind = sniffImage(Buffer.from(m[2].replace(/[\r\n]/g, ''), 'base64'));
  if (!kind) return { ok: false, message: 'Photo file sahi image nahi hai' };
  return { ok: true, value: `data:${kind.mime};base64,${m[2].replace(/[\r\n]/g, '')}` };
}
// The photo the client sent back unchanged → keep it without re-validating (old rows stay as they are).
async function photoForUpdate(userId, incoming) {
  if (incoming === undefined) return { ok: true, keep: true };
  const cur = await dbGet(`SELECT photo FROM users WHERE id=?`, [userId]);
  if (cur && incoming === cur.photo) return { ok: true, keep: true };
  return cleanPhoto(incoming);
}
const USER_COLS = `id, name, email, role, photo, COALESCE(active, 1) AS active, created_at`;

// ════════════════════════════════════════════════════════════
//  API ROUTES
// ════════════════════════════════════════════════════════════

// ── AUTH: LOGIN / SERVER-SIDE SESSIONS ────────────────────
app.post('/api/login', async (req, res) => {
  try {
    const { email, password } = req.body || {};
    const ip = req.ip || req.socket.remoteAddress || '';
    if (!auth.loginAllowed(ip)) return res.status(429).json({ success: false, message: 'Too many login attempts. Try again later.' });
    if (typeof email !== 'string' || typeof password !== 'string' || !email || !password)
      return res.status(400).json({ success: false, message: 'Email and password required.' });
    const user = await dbGet(`SELECT id, name, email, role, photo, COALESCE(active, 1) AS active, password FROM users WHERE LOWER(email)=LOWER(?) LIMIT 1`, [email.trim()]);
    if (!user || !auth.verifyPassword(password, user.password)) {
      auth.loginFailed(ip);
      return res.status(401).json({ success: false, message: 'Invalid email or password.' });
    }
    if (Number(user.active) === 0) return res.status(403).json({ success: false, message: 'Yeh account band (disabled) hai. Admin se rabta karein.' });
    auth.loginOk(ip);
    await auth.createSession(res, user);
    res.json({ success: true, user: { id:user.id, name:user.name, email:user.email, role:user.role, photo:user.photo || null, active: 1 } });
  } catch (e) {
    console.error('[login]', e.message);
    res.status(500).json({ success:false, message:'Login could not be completed.' });
  }
});
// Full profile of the logged-in user, INCLUDING the profile picture (so it shows after refresh / re-login).
app.get('/api/me', async (req, res) => {
  try {
    const u = await dbGet(`SELECT ${USER_COLS} FROM users WHERE id=?`, [req.user.id]);
    res.json({ success: true, user: u || req.user });
  } catch (e) { res.json({ success: true, user: req.user }); }
});

// Upload / replace / remove the logged-in user's OWN profile picture (Admin and Staff).
app.post('/api/me/photo', async (req, res) => {
  try {
    const ph = cleanPhoto(req.body && req.body.photo);
    if (!ph.ok) return res.status(400).json({ success: false, message: ph.message });
    await dbRun(`UPDATE users SET photo=? WHERE id=?`, [ph.value, req.user.id]);
    const u = await dbGet(`SELECT ${USER_COLS} FROM users WHERE id=?`, [req.user.id]);
    res.json({ success: true, user: u });
  } catch (e) { console.error('[me/photo]', e.message); res.status(500).json({ success: false, message: 'Photo save nahi hui' }); }
});
app.post('/api/logout', async (req, res) => {
  await auth.destroySession(req, res);
  res.json({ success:true });
});

app.post('/api/change-password', async (req, res) => {
  try {
    const { userId, newPassword } = req.body || {};
    if (req.user.role !== 'admin' || Number(userId) !== req.user.id)
      return res.status(403).json({ success:false, message:'You may only change your own admin password.' });
    if (typeof newPassword !== 'string' || newPassword.length < 12)
      return res.status(400).json({ success:false, message:'Password must have at least 12 characters.' });
    await dbRun(`UPDATE users SET password=? WHERE id=?`, [auth.hashPassword(newPassword), req.user.id]);
    await dbRun(`DELETE FROM sessions WHERE user_id=? AND token_hash NOT IN (SELECT token_hash FROM sessions WHERE user_id=? ORDER BY last_seen DESC LIMIT 1)`, [req.user.id, req.user.id]);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success:false, message:'Password update failed.' }); }
});

// ── USERS: GET ALL ──────────────────────────────────────────
app.get('/api/users', async (req, res) => {
  try {
    // Staff receive ONLY their own account — no admin details, no other staff.
    const users = isAdmin(req.user)
      ? await dbAll(`SELECT ${USER_COLS} FROM users ORDER BY role DESC, id ASC`)
      : await dbAll(`SELECT ${USER_COLS} FROM users WHERE id=?`, [req.user.id]);
    res.json({ success: true, users });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// ── USERS: UPDATE PROFILE ───────────────────────────────────
app.post('/api/users/update', async (req, res) => {
  try {
    const { id, name, email, photo } = req.body || {};
    if (!id) return res.json({ success: false, message: 'id required hai' });
    if (Number(id) !== req.user.id) return res.status(403).json({ success: false, message: 'You may edit only your own profile.' });
    const ph = await photoForUpdate(req.user.id, photo === undefined ? undefined : (photo || null));
    if (!ph.ok) return res.status(400).json({ success: false, message: ph.message });
    if (isAdmin(req.user)) {
      if (!name || !String(name).trim()) return res.json({ success: false, message: 'id aur name required hai' });
      if (ph.keep) await dbRun(`UPDATE users SET name=?, email=? WHERE id=?`, [String(name).trim(), String(email||'').trim(), id]);
      else await dbRun(`UPDATE users SET name=?, email=?, photo=? WHERE id=?`, [String(name).trim(), String(email||'').trim(), ph.value, id]);
    } else if (!ph.keep) {
      // Staff: name / email / login are managed by the Admin — only the own photo can change here.
      await dbRun(`UPDATE users SET photo=? WHERE id=?`, [ph.value, id]);
    }
    const updated = await dbGet(`SELECT ${USER_COLS} FROM users WHERE id=?`,[id]);
    res.json({ success: true, user: updated });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// ── STAFF: ADD ──────────────────────────────────────────────
app.post('/api/staff/add', requireAdmin, async (req, res) => {
  try {
    const { name, email, password, photo } = req.body || {};
    if (!name || !email || !password) return res.json({ success: false, message: 'Name, email, password required hai' });
    const ph = cleanPhoto(photo);
    if (!ph.ok) return res.status(400).json({ success: false, message: ph.message });
    if (typeof password !== 'string' || password.length < 8) return res.status(400).json({ success:false, message:'Staff password must be at least 8 characters.' });

    const exists = await dbGet(`SELECT id FROM users WHERE LOWER(email)=LOWER(?) LIMIT 1`, [email.trim()]);
    if (exists) return res.json({ success: false, message: 'Yeh email pehle se registered hai' });

    const result = await dbRun(
      `INSERT INTO users (name, email, password, role, photo, active) VALUES (?,?,?,?,?,1)`,
      [name.trim(), email.trim(), auth.hashPassword(password), 'staff', ph.value]
    );
    const newUser = await dbGet(`SELECT ${USER_COLS} FROM users WHERE id=?`,[result.lastID]);
    res.json({ success: true, user: newUser });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// ── STAFF: UPDATE ───────────────────────────────────────────
app.post('/api/staff/update', requireAdmin, async (req, res) => {
  try {
    const { id, name, email, password, photo, active } = req.body || {};
    if (!id) return res.json({ success: false, message: 'id required hai' });
    const target = await dbGet(`SELECT id, photo FROM users WHERE id=? AND role='staff'`, [id]);
    if (!target) return res.status(404).json({ success: false, message: 'Staff member nahi mila' });
    const ph = await photoForUpdate(target.id, photo === undefined ? undefined : (photo || null));
    if (!ph.ok) return res.status(400).json({ success: false, message: ph.message });
    const photoVal = ph.keep ? target.photo : ph.value;

    if (password && password.trim()) {
      if (password.length < 8) return res.status(400).json({ success:false, message:'Staff password must be at least 8 characters.' });
      await dbRun(`UPDATE users SET name=?, email=?, password=?, photo=? WHERE id=? AND role='staff'`,
        [name, email, auth.hashPassword(password), photoVal, id]);
      await dbRun(`DELETE FROM sessions WHERE user_id=?`, [id]);   // new password → old logins end
    } else {
      await dbRun(`UPDATE users SET name=?, email=?, photo=? WHERE id=? AND role='staff'`,
        [name, email, photoVal, id]);
    }
    // Account status: 1 = active, 0 = disabled (cannot log in; open sessions end now)
    if (active !== undefined) {
      const on = (active === true || active === 1 || active === '1') ? 1 : 0;
      await dbRun(`UPDATE users SET active=? WHERE id=? AND role='staff'`, [on, id]);
      if (!on) await dbRun(`DELETE FROM sessions WHERE user_id=?`, [id]);
    }
    const updated = await dbGet(`SELECT ${USER_COLS} FROM users WHERE id=?`,[id]);
    res.json({ success: true, user: updated });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// ── STAFF: DELETE ───────────────────────────────────────────
app.delete('/api/staff/:id', requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    // Their orders stay (Admin still sees them under Staff Orders, with the saved creator name).
    await dbRun(`DELETE FROM users WHERE id=? AND role='staff'`, [id]);
    await dbRun(`DELETE FROM sessions WHERE user_id=?`, [id]).catch(() => {});
    res.json({ success: true });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// ── ORDERS: GET ALL ─────────────────────────────────────────
app.get('/api/orders', async (req, res) => {
  try {
    // Admin: all orders. Staff: only their own (filtered in SQL — other rows never leave the server).
    const scope = orderScope(req.user, 'o');
    const orders = await dbAll(`SELECT o.*, (SELECT COUNT(*) FROM order_screenshots s WHERE s.order_id=o.id) AS screenshot_count
                                FROM orders o WHERE ${scope.sql} ORDER BY o.id ASC`, scope.params);
    res.json({ success: true, orders });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// ── ORDERS: GET ONE (ownership-checked) ─────────────────────
app.get('/api/orders/:id(\\d+)', requireOrderAccess, async (req, res) => {
  const order = await dbGet(`SELECT o.*, (SELECT COUNT(*) FROM order_screenshots s WHERE s.order_id=o.id) AS screenshot_count
                             FROM orders o WHERE o.id=?`, [req.order.id]);
  res.json({ success: true, order });
});

// ── ORDERS: ADD (manual form) ───────────────────────────────
// With `whatsapp` in the body (manual Place Order with screenshot) it goes through the
// SAME placeOrder() as AI orders → same WhatsApp. Without it (old callers) it just saves.
app.post('/api/orders/add', async (req, res) => {
  try {
    const { name, phone, detail, amount, advance, status, assigned_to, tracking_id, date, month, year, source } = req.body;
    if (!name || !phone || !amount) return res.json({ success: false, message: 'Name, phone, amount required hai' });
    const waIn = (req.body.whatsapp && typeof req.body.whatsapp === 'object') ? req.body.whatsapp : null;
    let whatsapp = null;
    if (waIn) {
      const phones = Array.isArray(req.body.phones) ? req.body.phones.map(String) : phoneUtil.split(phone);
      whatsapp = await checkWhatsAppOrder({ waIn, phones, lines: req.body.lines });
      if (!whatsapp.ok) return res.json({ success: false, code: 'validation', message: whatsapp.message });
    }
    const out = await placeOrder({
      name, phone, detail, amount, advance, status, tracking_id, date, month, year,
      // Staff orders are always assigned to the staff member who placed them
      assigned_to: isAdmin(req.user) ? assigned_to : req.user.id,
      source: source === 'ai_screenshot' ? 'ai_screenshot' : 'manual',
    }, { address: cleanAddress(req.body.address), whatsapp, owner: ownerOf(req.user) });
    res.json({ success: true, order: out.order, whatsapp: { started: out.waStarted } });
  } catch (e) {
    console.error('[orders/add]', e.stack || e.message);
    res.json({ success: false, code: 'save_failed', message: 'Order could not be saved. WhatsApp was not opened.', detail: e.message });
  }
});

// ── ORDERS: UPDATE STATUS ───────────────────────────────────
app.post('/api/orders/status', async (req, res) => {
  try {
    const { id, status } = req.body || {};
    if (!id || !status) return res.json({ success: false, message: 'id aur status required hai' });
    const acc = await orderForUser(req.user, id);
    if (!acc.order) return res.status(acc.status).json(acc.body);
    await dbRun(`UPDATE orders SET status=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`, [status, acc.order.id]);
    const updated = await dbGet(`SELECT * FROM orders WHERE id=?`,[acc.order.id]);
    res.json({ success: true, order: updated });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// ── ORDERS: UPDATE FULL ORDER (Edit modal) ──────────────────
app.post('/api/orders/update', async (req, res) => {
  try {
    const { id, name, phone, detail, amount, advance, status, assigned_to, tracking_id } = req.body || {};
    if (!id || !name || !phone || !amount) return res.json({ success: false, message: 'id, name, phone, amount required hai' });
    const acc = await orderForUser(req.user, id);
    if (!acc.order) return res.status(acc.status).json(acc.body);
    const prevRow = acc.order;
    // created_by_* (the owner) is never part of an edit — it stays with whoever placed the order.
    // Staff cannot re-assign; the existing assignment is kept.
    const assign = isAdmin(req.user) ? (assigned_to || 1) : (prevRow.assigned_to || req.user.id);
    await dbRun(
      `UPDATE orders SET name=?, phone=?, detail=?, amount=?, advance=?, status=?, assigned_to=?, tracking_id=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`,
      [name, phone, detail||'', amount, advance||0, status||'Processing', assign, tracking_id||'', prevRow.id]
    );
    await recordShipment(prevRow.id, prevRow.tracking_id, tracking_id)
      .catch(e => console.warn(`[orders/update] #${id} shipped_date save fail:`, e.message));
    const updated = await dbGet(`SELECT * FROM orders WHERE id=?`, [prevRow.id]);
    res.json({ success: true, order: updated });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// ── ORDERS: DELETE ──────────────────────────────────────────
app.delete('/api/orders/:id', async (req, res) => {
  try {
    if (!isAdmin(req.user)) return res.status(403).json({ success: false, message: 'Owner access only' });   // also blocked in auth.js
    const id = parseInt(req.params.id);
    const shotRows = await dbAll(`SELECT file_name FROM order_screenshots WHERE order_id=?`, [id]).catch(() => []);
    await dbRun(`DELETE FROM orders WHERE id=?`, [id]);
    storage.remove(shotRows.map(r => r.file_name)).catch(e => console.warn('[storage] cleanup:', e.message));
    await dbRun(`DELETE FROM order_screenshots WHERE order_id=?`, [id])
      .catch(e => console.warn(`[orders/delete] #${id} screenshot rows:`, e.message));
    if (Number.isInteger(id) && id > 0) fs.rm(path.join(SS_ROOT, 'orders', String(id)), { recursive: true, force: true },
      e => { if (e) console.warn(`[orders/delete] #${id} screenshot files:`, e.message); });
    res.json({ success: true });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// ════════════════════════════════════════════════════════════
//  👥 ADMIN — STAFF ORDERS (owner only; also blocked for staff in auth.js)
//  GET /api/staff-orders?staff=<id|all>&status=<all|Processing|Delivered|Return|Paid|Unpaid>
//                        &from=YYYY-MM-DD&to=YYYY-MM-DD&q=<order id | customer | phone | tracking>
//  Only orders placed by Staff (created_by_role='staff'). Admin's own orders are never mixed in.
//  overall + perStaff follow the date range only; the list follows every filter combined.
// ════════════════════════════════════════════════════════════
const ORDER_DAY = `COALESCE(NULLIF(o.placed_date, ''), SUBSTR(CAST(o.created_at AS TEXT), 1, 10))`;
const STAT_COLS = `COUNT(*) AS total,
  SUM(CASE WHEN o.status = 'Processing' THEN 1 ELSE 0 END) AS pending,
  SUM(CASE WHEN o.status = 'Delivered'  THEN 1 ELSE 0 END) AS delivered,
  SUM(CASE WHEN o.status = 'Return'     THEN 1 ELSE 0 END) AS returned,
  SUM(CASE WHEN o.status = 'Paid'       THEN 1 ELSE 0 END) AS paid,
  SUM(CASE WHEN o.status = 'Paid' THEN 0 ELSE 1 END)       AS unpaid,
  COALESCE(SUM(o.amount), 0) AS amount`;
const statNums = r => ({
  total: Number(r && r.total) || 0, pending: Number(r && r.pending) || 0, delivered: Number(r && r.delivered) || 0,
  returned: Number(r && r.returned) || 0, paid: Number(r && r.paid) || 0, unpaid: Number(r && r.unpaid) || 0,
  amount: Number(r && r.amount) || 0,
});
const isoDay = v => (typeof v === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(v)) ? v : null;

app.get('/api/staff-orders', async (req, res) => {
  try {
    if (!isAdmin(req.user)) return res.status(403).json({ success: false, message: 'Owner access only' });
    const qy = req.query || {};
    const from = isoDay(qy.from), to = isoDay(qy.to);
    const base = [`o.created_by_role = 'staff'`], baseP = [];
    if (from) { base.push(`${ORDER_DAY} >= ?`); baseP.push(from); }
    if (to)   { base.push(`${ORDER_DAY} <= ?`); baseP.push(to); }

    const overall = statNums(await dbGet(`SELECT ${STAT_COLS} FROM orders o WHERE ${base.join(' AND ')}`, baseP));
    const grouped = await dbAll(`SELECT o.created_by_user_id AS uid, MAX(o.created_by_name) AS saved_name, ${STAT_COLS}
                                 FROM orders o WHERE ${base.join(' AND ')} GROUP BY o.created_by_user_id`, baseP);
    const staffUsers = await dbAll(`SELECT id, name, email, photo, COALESCE(active, 1) AS active FROM users WHERE role='staff' ORDER BY name ASC`);
    const byId = new Map(grouped.map(g => [Number(g.uid), g]));
    const perStaff = staffUsers.map(u => ({ id: u.id, name: u.name, email: u.email, photo: u.photo || null,
      active: Number(u.active) !== 0, deleted: false, ...statNums(byId.get(Number(u.id))) }));
    for (const g of grouped) {          // staff accounts deleted later — their orders are still listed
      if (!staffUsers.some(u => Number(u.id) === Number(g.uid)))
        perStaff.push({ id: Number(g.uid), name: g.saved_name || `Staff #${g.uid}`, email: '', photo: null, active: false, deleted: true, ...statNums(g) });
    }

    const where = [...base], params = [...baseP];
    const staffId = Number(qy.staff);
    if (qy.staff && qy.staff !== 'all') {
      if (!Number.isInteger(staffId) || staffId <= 0) return res.status(400).json({ success: false, message: 'Invalid staff filter' });
      where.push(`o.created_by_user_id = ?`); params.push(staffId);
    }
    const st = String(qy.status || 'all');
    if (st === 'Unpaid') where.push(`o.status <> 'Paid'`);
    else if (['Processing', 'Delivered', 'Return', 'Paid', 'Cancelled'].includes(st)) { where.push(`o.status = ?`); params.push(st); }
    const q = String(qy.q || '').trim().slice(0, 80);
    if (q) {
      const like = '%' + q.toLowerCase().replace(/[%_\\]/g, '') + '%';
      const digits = q.replace(/\D/g, '');
      const idMatch = /^(?:#|MA-\d{4}-)?(\d{1,9})$/i.exec(q);
      const ors = [`LOWER(o.name) LIKE ?`, `LOWER(o.phone) LIKE ?`, `LOWER(COALESCE(o.tracking_id, '')) LIKE ?`];
      params.push(like, like, like);
      if (digits.length >= 4) { ors.push(`REPLACE(REPLACE(o.phone, '-', ''), ' ', '') LIKE ?`); params.push('%' + digits + '%'); }
      if (idMatch) { ors.push(`o.id = ?`); params.push(Number(idMatch[1])); }
      where.push('(' + ors.join(' OR ') + ')');
    }
    const LIMIT = 1000;
    const orders = await dbAll(`SELECT o.*, ${ORDER_DAY} AS order_day,
                                       COALESCE(u.name, o.created_by_name) AS created_by_display,
                                       (SELECT COUNT(*) FROM order_screenshots s WHERE s.order_id=o.id) AS screenshot_count
                                FROM orders o LEFT JOIN users u ON u.id = o.created_by_user_id
                                WHERE ${where.join(' AND ')} ORDER BY o.id DESC LIMIT ${LIMIT}`, params);
    res.json({ success: true, overall, perStaff, orders, limited: orders.length >= LIMIT });
  } catch (e) {
    console.error('[staff-orders]', e.message);
    res.status(500).json({ success: false, message: 'Staff orders load nahi huay' });
  }
});

// ── SETTINGS: GET ───────────────────────────────────────────
app.get('/api/settings', async (req, res) => {
  try {
    // Staff only get the branding they need to render the CRM — never admin settings.
    const STAFF_SETTINGS = ['macrm_logo', 'macrm_store_name', 'macrm_report_logo'];
    const rows = isAdmin(req.user)
      ? await dbAll(`SELECT key, value FROM settings`)
      : await dbAll(`SELECT key, value FROM settings WHERE key IN (${STAFF_SETTINGS.map(() => '?').join(',')})`, STAFF_SETTINGS);
    const settings = {};
    rows.forEach(r => settings[r.key] = r.value);
    res.json({ success: true, settings });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// ── SETTINGS: SET ───────────────────────────────────────────
app.post('/api/settings/set', async (req, res) => {
  try {
    const { key, value } = req.body;
    if (!key) return res.json({ success: false, message: 'key required hai' });
    await dbRun(`INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT (key) DO UPDATE SET value=excluded.value`, [key, value||'']);
    res.json({ success: true });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// ════════════════════════════════════════════════════════════
//  📊 REPORT API — Monthly Report Module
// ════════════════════════════════════════════════════════════

// ── REPORT: GET MONTHLY DATA ────────────────────────────────
// Usage: GET /api/report/2026/5
// month: 1–12 (integer), year: 2025, 2026 etc.
app.get('/api/report/:year/:month', async (req, res) => {
  try {
    const year  = parseInt(req.params.year);
    const month = parseInt(req.params.month); // 1–12 (from report page)
    // NOTE: Existing orders in DB were saved with JS getMonth() which is 0-based
    // So May (month=5) was saved as 4 in DB. We query month-1 to match.
    const dbMonth = month - 1; // 0-based to match existing data

    // ── Summary stats ───────────────────────────────────────
    const summary = await dbGet(`
      SELECT
        COUNT(*)                                                        AS "totalOrders",
        COUNT(DISTINCT name || phone)                                   AS "totalClients",
        SUM(CASE WHEN status IN ('Delivered','delivered') THEN 1 ELSE 0 END) AS delivered,
        SUM(CASE WHEN status IN ('Cancelled','cancelled') THEN 1 ELSE 0 END) AS cancelled,
        SUM(CASE WHEN status IN ('Processing','processing','Paid') THEN 1 ELSE 0 END) AS processing,
        COALESCE(SUM(amount), 0)                                        AS "totalRevenue",
        COALESCE(SUM(advance), 0)                                       AS received,
        COALESCE(SUM(amount) - SUM(advance), 0)                        AS pending
      FROM orders
      WHERE month = ? AND year = ?
    `, [dbMonth, year]);

    // ── All orders for this month ───────────────────────────
    const orders = await dbAll(`
      SELECT
        o.id,
        o.name        AS "clientName",
        o.phone,
        o.detail      AS product,
        o.status,
        o.amount,
        o.advance     AS paid,
        (o.amount - o.advance) AS remaining,
        o.tracking_id,
        o.date,
        u.name        AS "assignedTo"
      FROM orders o
      LEFT JOIN users u ON o.assigned_to = u.id
      WHERE o.month = ? AND o.year = ?
      ORDER BY o.id ASC
    `, [dbMonth, year]);

    // ── Per-client aggregation ──────────────────────────────
    const clients = await dbAll(`
      SELECT
        name                     AS "clientName",
        phone,
        COUNT(*)                 AS "totalOrders",
        COALESCE(SUM(amount), 0) AS "totalSpend",
        COALESCE(SUM(advance), 0) AS "totalPaid",
        COALESCE(SUM(amount) - SUM(advance), 0) AS "totalPending"
      FROM orders
      WHERE month = ? AND year = ?
      GROUP BY name, phone
      ORDER BY "totalSpend" DESC
    `, [dbMonth, year]);

    res.json({
      success: true,
      year, month,
      summary,
      orders,
      clients
    });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// ── REPORT: ALL MONTHS LIST (for dropdown) ──────────────────
app.get('/api/report/months', async (req, res) => {
  try {
    const months = await dbAll(`
      SELECT DISTINCT month, year, COUNT(*) as "orderCount"
      FROM orders
      GROUP BY year, month
      ORDER BY year DESC, month DESC
    `);
    res.json({ success: true, months });
  } catch (e) {
    res.json({ success: false, message: e.message });
  }
});

// ════════════════════════════════════════════════════════════
//  🤖 AI SCREENSHOT IMPORT → PLACE ORDER
//  Flow: screenshot → Gemini → validated JSON → review screen
//        → human confirms → /api/clients/save → database
//  /api/ai/extract NEVER writes to the database.
// ════════════════════════════════════════════════════════════

// Rate limit per browser (protects the API key's quota). Only one job per user runs at a time: a new upload cancels the old job.
const aiHits = new Map();
const AI_WINDOW_MS = 10 * 60 * 1000, AI_MAX_PER_WINDOW = 30;
function aiRateOk(ip) {
  const now = Date.now();
  const hits = (aiHits.get(ip) || []).filter(t => now - t < AI_WINDOW_MS);
  if (hits.length >= AI_MAX_PER_WINDOW) { aiHits.set(ip, hits); return false; }
  hits.push(now); aiHits.set(ip, hits);
  return true;
}

const AI_USER_MESSAGES = {
  config:       'AI import is not set up correctly on the server.',
  timeout:      'Gemini took too long to answer.',
  rate_limited: 'Gemini usage limit reached — wait a minute and retry.',
  blocked:      'Gemini refused to read this screenshot.',
  invalid_json: 'Gemini answered, but the answer could not be read.',
  empty:        'Gemini sent an empty answer.',
  bad_request:  'Gemini rejected the request.',
  network:      'The server could not connect to Gemini — check the internet connection, firewall or antivirus.',
  upstream:     'Gemini had a problem answering.',
  bad_image:    'This file could not be used as a screenshot.',
};

// ── AI: STATUS (is the feature configured?) ─────────────────
app.get('/api/ai/status', (req, res) => {
  res.json({
    success: true,
    enabled: AI_ENABLED,
    model: GEMINI_API_KEY ? GEMINI_MODEL : (NVIDIA_API_KEY ? NVIDIA_MODEL : null),
    backups: { geminiKeys: Math.max(0, GEMINI_KEYS.length - 1), nvidia: NVIDIA_API_KEY ? NVIDIA_MODEL : null },
    maxImages: ai.LIMITS.MAX_IMAGES,
    reason: AI_ENABLED ? null : (envInfo.file || envInfo.fromEnvVar ? (keyCheck.problem || 'empty') : 'no_env_file'),
    health: aiHealth,
    rapidocr: { enabled: rapidocr.RAPIDOCR_ENABLED, baseUrl: rapidocr.RAPIDOCR_BASE_URL },
  });
});

// ── Gemini busy (HTTP 500/502/503/504, "high demand") → retry automatically ──
// A 503 means Google's servers were overloaded; the screenshot never got read.
// Retry the same model with a short wait, then try any backup models.
// Only ONE short retry, ever — regardless of whether a backup key/model exists.
// (Previously a single-key setup got up to 4 attempts at a 60s timeout each — over
// 4 minutes worst case. Partial results beat a complete-but-slow one, so we now fail
// fast to manual entry instead of hammering the same provider.)
const AI_RETRY_WAITS_MS = [1500];
// At most this many providers/models are tried per screenshot (no hammering the quota with repeats).
const AI_MAX_PROVIDER_ATTEMPTS = Number(process.env.AI_MAX_PROVIDER_ATTEMPTS) || 3;
function aiIsTransient(e) {
  if (!e) return false;
  if (e.code === 'config' || e.code === 'bad_request' || e.code === 'blocked' || e.code === 'bad_image') return false;
  const text = `${e.message || ''} ${e.detail || ''}`;
  return /\b(500|502|503|504)\b|UNAVAILABLE|overloaded|high demand|try again later|INTERNAL|DEADLINE_EXCEEDED/i.test(text)
    || e.code === 'timeout' || e.code === 'network';
}
// Sleeps ms — but wakes up immediately if the browser disconnects, instead of
// finishing the whole wait in the background after the user has given up.
const aiSleep = (ms, signal) => new Promise(r => {
  const t = setTimeout(r, ms);
  if (signal) signal.addEventListener('abort', () => { clearTimeout(t); r(); }, { once: true });
});
// HTTP 429 / RESOURCE_EXHAUSTED = this model's quota for the API key is used up.
// Retrying the same model is pointless, but each model has its OWN quota → try the backups.
function aiIsQuota(e) {
  return !!e && (e.code === 'rate_limited' || /\b429\b|RESOURCE_EXHAUSTED|quota/i.test(`${e.message || ''} ${e.detail || ''}`));
}
// Providers are tried in this order: every Gemini key (main model, then backup models),
// then NVIDIA. A provider that just failed is skipped for a while (cool-down) so the NEXT
// screenshots go straight to a working one instead of waiting through the same errors again.
// Each screenshot is handled on its own: the ones already read are never redone.
const aiCooldown = new Map();               // provider id → timestamp until which it is skipped
const AI_COOLDOWN_QUOTA_MS = 120000;        // 429
const AI_COOLDOWN_BUSY_MS  = 30000;         // 503 etc.
const AI_COOLDOWN_KEY_MS   = 600000;        // bad key / model missing
function aiBuildChain() {
  const chain = [];
  GEMINI_KEYS.forEach((key, ki) => {
    [GEMINI_MODEL, ...GEMINI_FALLBACK_MODELS].forEach(model =>
      chain.push({ id: `gemini${ki}:${model}`, kind: 'gemini', key, model, label: `Gemini key ${ki + 1} / ${model}` }));
  });
  if (NVIDIA_API_KEY) chain.push({ id: `nvidia:${NVIDIA_MODEL}`, kind: 'nvidia', model: NVIDIA_MODEL, label: `NVIDIA / ${NVIDIA_MODEL}` });
  return chain;
}
async function aiCallGeminiWithRetry(opts, log, signal) {
  const chain = aiBuildChain();
  if (!chain.length) throw new ai.AiError('config', AI_USER_MESSAGES.config);
  const now = Date.now();
  let usable = chain.filter(c => (aiCooldown.get(c.id) || 0) <= now);
  if (!usable.length) usable = chain;           // everything cooling down → just try them all again
  const tried = [];
  const errs = [];
  for (const [n, entry] of usable.entries()) {
    if (n >= AI_MAX_PROVIDER_ATTEMPTS) break;
    if (signal && signal.aborted) throw new ai.AiError('aborted', 'Request was cancelled by the browser');
    // First provider gets one quick retry; every other provider in the chain gets none —
    // move straight on to the next key/model rather than waiting on one that's already slow.
    const waits = n === 0 ? AI_RETRY_WAITS_MS : [];
    for (let attempt = 0; attempt <= waits.length; attempt++) {
      try {
        const out = entry.kind === 'gemini'
          ? await ai.callGemini({ ...opts, apiKey: entry.key, model: entry.model, signal })
          : await ai.callNvidia({ apiKey: NVIDIA_API_KEY, model: entry.model, baseUrl: NVIDIA_BASE_URL, image: opts.image, index: opts.index, total: opts.total, ocrText: opts.ocrText, signal });
        if (n > 0 || attempt) log(`succeeded on ${entry.label} (attempt ${attempt + 1})`);
        aiCooldown.delete(entry.id);
        return { ...out, provider: entry.label };
      } catch (e) {
        if (e.code === 'aborted' || e.code === 'bad_image' || e.code === 'blocked') throw e;   // not a provider problem
        errs.push(e);
        if (aiIsQuota(e)) {
          aiCooldown.set(entry.id, Date.now() + AI_COOLDOWN_QUOTA_MS);
          tried.push(`${entry.label}: quota (429)`);
          log(`${entry.label} quota used up (429) — switching to the next provider`);
          break;
        }
        if (!aiIsTransient(e)) {
          aiCooldown.set(entry.id, Date.now() + (e.code === 'config' ? AI_COOLDOWN_KEY_MS : AI_COOLDOWN_BUSY_MS));
          tried.push(`${entry.label}: not usable (${e.code || 'error'})`);
          log(`${entry.label} failed: ${e.message} — switching to the next provider`);
          break;
        }
        if (attempt < waits.length) {
          log(`${entry.label} busy (${e.message}) — retrying in ${waits[attempt] / 1000}s`);
          await aiSleep(waits[attempt], signal);
        } else {
          aiCooldown.set(entry.id, Date.now() + AI_COOLDOWN_BUSY_MS);
          tried.push(`${entry.label}: busy`);
          log(`${entry.label} busy — switching to the next provider`);
        }
      }
    }
  }
  if (signal && signal.aborted) throw new ai.AiError('aborted', 'Request was cancelled by the browser');
  const lastErr = errs.find(aiIsQuota) || errs.find(aiIsTransient) || errs[errs.length - 1] || new ai.AiError('upstream', 'No AI provider could read this screenshot');
  const names = chain.length > 1 ? `sab ${chain.length} options (Gemini + backup)` : 'Gemini';
  if (aiIsQuota(lastErr)) {
    lastErr.code = 'rate_limited';
    lastErr.message = `AI ki quota khatam ho gayi hai (HTTP 429) — ${names} try kiye. Code ki ghalti nahi: provider ne limit band kar di hai.`;
  } else if (aiIsTransient(lastErr)) {
    lastErr.message = `AI abhi bohat busy hai — ${names} try kiye. Screenshot ki koi ghalti nahi. 1–2 minute baad Retry karein.`;
  }
  lastErr.detail = `[server v4] Tried → ${tried.join(' | ')}. ${lastErr.detail || ''}`.slice(0, 500);
  throw lastErr;
}

// Runs fn over items with at most `limit` at once (keeps 5 screenshots from hitting the API in one burst)
async function aiMapLimit(items, limit, fn) {
  const out = new Array(items.length);
  let next = 0;
  const worker = async () => { while (next < items.length) { const i = next++; out[i] = await fn(items[i], i); } };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return out;
}

// Only these details are taken from a parcel screenshot (PostEx etc.):
// name, phone number(s), address, tracking ID, price (COD amount).
// Product + quantity: kept if the extractor returns them (order.lines / order.items);
// otherwise the review form uses the CRM default ("Safoof").
// Everything else the model returns (email, notes, ...) is dropped here.
const AI_CLIENT_FIELDS = ['name', 'phones', 'phone_unreadable', 'address'];
const AI_ORDER_FIELDS  = ['tracking_id', 'cod_amount', 'lines', 'items', 'product_name'];
function aiKeepOrderFieldsOnly(draft) {
  if (!draft || typeof draft !== 'object') return draft;
  const pick = (obj, keys) => {
    const out = {};
    if (obj && typeof obj === 'object') keys.forEach(k => { if (k in obj) out[k] = obj[k]; });
    return out;
  };
  draft.client = pick(draft.client, AI_CLIENT_FIELDS);
  draft.order  = pick(draft.order, AI_ORDER_FIELDS);
  const allowed = new Set([...AI_CLIENT_FIELDS, ...AI_ORDER_FIELDS, 'phone']);
  if (Array.isArray(draft.warnings)) {
    draft.warnings = draft.warnings.filter(w => !w || !w.field || allowed.has(w.field));
  }
  const has = f => f && f.value !== null && f.value !== undefined && f.value !== '';
  const filled = (has(draft.client.name) ? 1 : 0)
    + (has(draft.client.address) ? 1 : 0)
    + (Array.isArray(draft.client.phones) ? draft.client.phones.length : 0)
    + (has(draft.order.tracking_id) ? 1 : 0)
    + (has(draft.order.cod_amount) ? 1 : 0)
    + (Array.isArray(draft.order.lines) ? draft.order.lines.length : (Array.isArray(draft.order.items) ? draft.order.items.length : 0));
  draft.stats = Object.assign({}, draft.stats, { filled });
  return draft;
}

// ── AI: EXTRACT — a cancellable JOB (saves nothing, never creates an order) ──
//   POST /api/ai/extract            {jobId, images}  → starts the job, answers at once
//   GET  /api/ai/extract/:id?rev=N                   → progress + (partial → final) draft
//   POST /api/ai/extract/:id/cancel                  → aborts RapidOCR + Gemini, marks it cancelled
// RapidOCR runs first (~4 s) and its result is published immediately; Gemini then verifies it
// against the image. Hard limit for the whole job: 120 s (EXTRACT_HARD_LIMIT_MS).
const extraction = createExtractionService({
  ai, rapidocr,
  geminiAvailable: () => aiBuildChain().length > 0,
  callGemini: (opts, log, signal) => aiCallGeminiWithRetry({ apiKey: GEMINI_API_KEY, model: GEMINI_MODEL, ...opts }, log, signal),
  finalizeDraft: aiKeepOrderFieldsOnly,
  log: msg => console.log(msg),
});
const extractOwner = req => String((req.user && req.user.id) || req.ip || 'anon');

app.post('/api/ai/extract', async (req, res) => {
  try {
    if (!AI_ENABLED) return res.json({ success: false, code: 'config', message: AI_USER_MESSAGES.config });
    const owner = extractOwner(req);
    const mgr = extraction.manager;
    const ip = req.ip || (req.socket && req.socket.remoteAddress) || 'local';
    const reqId = req.body && req.body.jobId;
    const jobId = reqId === undefined || reqId === null || reqId === '' ? mgr.newId() : reqId;
    if (!mgr.validId(jobId)) return res.json({ success: false, code: 'bad_image', message: 'Invalid extraction job id.' });
    if (mgr.wasCancelled(owner, jobId)) return res.json({ success: false, code: 'cancelled', message: 'Extraction was cancelled.' });
    if (mgr.get(owner, jobId)) return res.json({ success: false, code: 'busy', message: 'This extraction job already exists.' });
    if (!aiRateOk(ip)) return res.json({ success: false, code: 'rate_limited', message: 'Too many extractions in a short time. Wait a few minutes.' });

    const imagesIn = Array.isArray(req.body && req.body.images) ? req.body.images : [];
    if (!imagesIn.length) return res.json({ success: false, code: 'bad_image', message: 'Upload at least one screenshot.' });
    if (imagesIn.length > ai.LIMITS.MAX_IMAGES) return res.json({ success: false, code: 'bad_image', message: `Maximum ${ai.LIMITS.MAX_IMAGES} screenshots per import.` });
    let images;
    try { images = imagesIn.map((img, i) => ai.decodeImage(img, i + 1)); }
    catch (e) { console.warn('[AI import] bad image:', e.message); return res.json({ success: false, code: 'bad_image', message: e.message }); }

    // A new screenshot always starts a FRESH job: whatever this user still has running is cancelled first.
    const old = mgr.active(owner);
    if (old) { console.log(`[extract ${old.id.slice(0, 6)}] superseded by a new upload — cancelling`); mgr.cancel(owner, old.id, 'superseded'); }

    extraction.start(owner, jobId, images);
    res.json({ success: true, jobId, state: 'running', hardLimitMs: mgr.HARD_LIMIT_MS });
  } catch (e) {
    console.error('[AI import] unexpected error:', e && e.stack || e);
    res.json({ success: false, code: 'upstream', message: 'Unexpected server error while reading the screenshot.', detail: String(e && e.message || e).slice(0, 200) });
  }
});

app.get('/api/ai/extract/:jobId', (req, res) => {
  const mgr = extraction.manager;
  const job = mgr.validId(req.params.jobId) ? mgr.get(extractOwner(req), req.params.jobId) : null;
  if (!job) return res.json({ success: false, code: 'not_found', message: 'Extraction job not found (it may have expired or been cancelled).' });
  const since = req.query.rev !== undefined && req.query.rev !== '' ? Number(req.query.rev) : undefined;
  res.json({ success: true, job: mgr.snapshot(job, Number.isFinite(since) ? since : undefined) });
});

app.post('/api/ai/extract/:jobId/cancel', (req, res) => {
  const mgr = extraction.manager;
  if (!mgr.validId(req.params.jobId)) return res.json({ success: false, code: 'bad_image', message: 'Invalid job id.' });
  const r = mgr.cancel(extractOwner(req), req.params.jobId, 'user');
  console.log(`[extract ${req.params.jobId.slice(0, 6)}] cancel requested by user — ${r.found ? r.state : 'job not started yet (blocked)'}`);
  res.json({ success: true, state: r.found ? r.state : 'cancelled' });
});

// ════════════════════════════════════════════════════════════
//  📎 ORIGINAL SCREENSHOTS
//  Uploaded the moment the user adds a screenshot, stored exactly as
//  received (no resize / re-encode). Upload sends NOTHING to WhatsApp.
// ════════════════════════════════════════════════════════════
const SS_ID_RE = /^[a-f0-9]{32}\.(png|jpg|webp)$/;
const SS_MAX_BYTES = 20 * 1024 * 1024;
const sha256 = buf => crypto.createHash('sha256').update(buf).digest('hex');
function sniffImage(buf) {
  if (buf.length > 8 && buf[0] === 0x89 && buf.toString('ascii', 1, 4) === 'PNG') return { mime: 'image/png', ext: 'png' };
  if (buf.length > 3 && buf[0] === 0xFF && buf[1] === 0xD8 && buf[2] === 0xFF) return { mime: 'image/jpeg', ext: 'jpg' };
  if (buf.length > 12 && buf.toString('ascii', 0, 4) === 'RIFF' && buf.toString('ascii', 8, 12) === 'WEBP') return { mime: 'image/webp', ext: 'webp' };
  return null;
}

app.post('/api/screenshots/temp', express.raw({ type: () => true, limit: '25mb' }), async (req, res) => {
  try {
    const buf = req.body;
    if (!Buffer.isBuffer(buf) || !buf.length) return res.json({ success: false, code: 'bad_image', message: 'Screenshot file khali hai' });
    if (buf.length > SS_MAX_BYTES) return res.json({ success: false, code: 'too_large', message: 'Screenshot 20 MB se bara hai' });
    const kind = sniffImage(buf);
    if (!kind) return res.json({ success: false, code: 'bad_image', message: 'Sirf PNG, JPG ya WEBP screenshot chalte hain' });
    let name = '';
    try { name = decodeURIComponent(req.get('X-File-Name') || ''); }
    catch (e) { console.warn('[screenshots/temp] file name not decodable, saving without name'); }
    name = name.replace(/[\\/\x00-\x1f"]/g, '').slice(0, 120);
    const id = crypto.randomBytes(16).toString('hex') + '.' + kind.ext;
    const meta = { name, mime: kind.mime, bytes: buf.length, sha256: sha256(buf), uploaded_at: new Date().toISOString() };
    await fs.promises.writeFile(path.join(SS_TMP, id), buf, { flag: 'wx' });
    await fs.promises.writeFile(path.join(SS_TMP, id + '.json'), JSON.stringify(meta));
    res.json({ success: true, id, sha256: meta.sha256, bytes: meta.bytes, mime: meta.mime });
  } catch (e) {
    console.error('[screenshots/temp]', e.message);
    res.json({ success: false, code: 'upload_failed', message: 'Screenshot server par save nahi hua: ' + e.message });
  }
});

app.get('/api/orders/:id/screenshots', requireOrderAccess, async (req, res) => {
  try {
    const id = req.order.id;
    const rows = await dbAll(`SELECT id, position, original_name, mime, bytes FROM order_screenshots WHERE order_id=? ORDER BY position ASC`, [id]);
    res.json({ success: true, screenshots: rows.map(r => ({ ...r, url: `/api/orders/${id}/screenshots/${r.id}/file` })) });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

app.get('/api/orders/:id/screenshots/:sid/file', requireOrderAccess, async (req, res) => {
  try {
    const row = await dbGet(`SELECT file_name, mime, position FROM order_screenshots WHERE id=? AND order_id=?`, [parseInt(req.params.sid), req.order.id]);
    if (!row) return res.status(404).json({ success: false, message: 'Screenshot nahi mila' });
    if (!(await storage.ensureLocal(SS_ROOT, row.file_name))) return res.status(404).json({ success: false, message: 'Screenshot file nahi mili' });
    // ?download=1 → "Download original" in the dispatch panel saves the exact original file.
    if (req.query.download === '1') {
      const ext = path.extname(row.file_name) || '';
      res.attachment(`${makeOrderCode(req.order)}-image-${Number(row.position) + 1}${ext}`);
    }
    res.type(row.mime).sendFile(path.join(SS_ROOT, row.file_name));
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
});

// Unplaced uploads older than 24h are removed (placed orders keep theirs forever)
async function cleanScreenshotTmp() {
  try {
    const cutoff = Date.now() - 24 * 60 * 60 * 1000;
    for (const f of await fs.promises.readdir(SS_TMP)) {
      const full = path.join(SS_TMP, f);
      const st = await fs.promises.stat(full).catch(() => null);
      if (st && st.isFile() && st.mtimeMs < cutoff) await fs.promises.unlink(full).catch(e => console.warn('[screenshots] tmp cleanup:', e.message));
    }
  } catch (e) { console.warn('[screenshots] tmp cleanup failed:', e.message); }
}

// ════════════════════════════════════════════════════════════
//  📅 ORDER PLACED DATE  +  📦 VPL 3-DAY WHATSAPP REMINDER
//  Separate from the order / WhatsApp-confirmation code: it only reads and writes
//  the new columns above and sends through waSender.sendText().
// ════════════════════════════════════════════════════════════
const localISODate = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const isVplTracking = t => /^VPL/i.test(String(t || '').trim());
// whole calendar days from `fromISO` to `toISO` (date only, no time-of-day / DST effects)
function daysBetween(fromISO, toISO) {
  const re = /^(\d{4})-(\d{2})-(\d{2})$/;
  const a = re.exec(fromISO || ''), b = re.exec(toISO || '');
  if (!a || !b) return null;
  return Math.round((Date.UTC(+b[1], +b[2] - 1, +b[3]) - Date.UTC(+a[1], +a[2] - 1, +a[3])) / 86400000);
}

// Called after an order's tracking ID is saved. A NEW VPL tracking ID = parcel shipped today.
// Same ID saved again (e.g. editing the status) never changes the date.
async function recordShipment(orderId, prevTracking, newTracking) {
  if (!isVplTracking(newTracking)) return;
  if (String(prevTracking || '').trim().toUpperCase() === String(newTracking).trim().toUpperCase()) return;
  await dbRun(`UPDATE orders SET shipped_date=?, vpl_reminder_sent=0, vpl_reminder_sent_at=NULL, vpl_reminder_error=NULL WHERE id=?`,
    [localISODate(), orderId]);
}

const VPL_REMINDER_TEXT = 'Assalam o Alaikum, aap ka parcel post office mein aa gaya hai. Barah-e-karam apne qareebi dak khane se apna parcel receive kar lein. Shukriya.';
// Parcel already with the customer / cancelled → "parcel post office mein aa gaya" would be wrong.
const VPL_SKIP_STATUSES = ['Delivered', 'Paid', 'Return', 'Cancelled'];
const VPL_RETRY_MS = 5 * 60 * 1000;

function vplNumber(o) {
  if (o.wa_phone) { const n = phoneUtil.normalize(o.wa_phone); if (n.ok) return n.number; }
  const p = phoneUtil.pickWhatsApp(phoneUtil.split(o.phone || ''));
  return p.ok ? p.number : null;
}

// Orders that qualify TODAY: VPL tracking + shipped date + EXACTLY 3 days + reminder not sent yet.
async function findVplDue(today = localISODate()) {
  const rows = await dbAll(
    `SELECT id, name, phone, wa_phone, status, tracking_id, shipped_date, created_by_user_id FROM orders
      WHERE shipped_date IS NOT NULL AND shipped_date <> ''
        AND COALESCE(vpl_reminder_sent, 0) = 0
        AND vpl_reminder_error IS NULL
        AND UPPER(TRIM(tracking_id)) LIKE 'VPL%'`);
  return rows.filter(o => daysBetween(o.shipped_date, today) === 3 && !VPL_SKIP_STATUSES.includes(o.status));
}

let vplRunning = false, vplWaitLogged = false;
async function runVplReminders(trigger) {
  if (vplRunning) return;
  vplRunning = true;
  try {
    const due = await findVplDue();
    if (!due.length) { if (trigger === 'startup') console.log('📦 VPL reminders: aaj koi parcel exactly 3 din ka nahi'); return; }
    if (waSender.status().state !== 'ready') {
      if (!vplWaitLogged) console.log(`📦 VPL reminders: ${due.length} parcel due hain, WhatsApp Web tab ready nahi — ${VPL_RETRY_MS / 60000} minute baad dobara check hoga`);
      vplWaitLogged = true;
      return;
    }
    vplWaitLogged = false;
    console.log(`📦 VPL reminders: ${due.length} parcel(s) ko 3-day reminder bhej raha hoon`);
    for (const o of due) {
      const fresh = await dbGet(`SELECT vpl_reminder_sent FROM orders WHERE id=?`, [o.id]);
      if (!fresh || fresh.vpl_reminder_sent) continue;            // duplicate protection
      const number = vplNumber(o);
      if (!number) { console.warn(`📦 VPL reminder #${o.id}: WhatsApp number sahi nahi — skip`); continue; }
      try {
        await waSender.sendText(number, VPL_REMINDER_TEXT);
        for (let attempt = 1; attempt <= 2; attempt++) {           // sent → mark YES right away
          try { await dbRun(`UPDATE orders SET vpl_reminder_sent=1, vpl_reminder_sent_at=CURRENT_TIMESTAMP WHERE id=?`, [o.id]); break; }
          catch (e) { console.error(`📦 VPL reminder #${o.id}: sent flag save fail (try ${attempt}):`, e.message); }
        }
        console.log(`📦 VPL reminder bhej diya → order #${o.id}`);
      } catch (e) {
        if (e.step === 'send') {   // outcome unknown — never risk a second message
          await dbRun(`UPDATE orders SET vpl_reminder_error=? WHERE id=?`, ['UNCERTAIN: ' + String(e.message).slice(0, 200), o.id]).catch(() => {});
          console.warn(`📦 VPL reminder #${o.id}: send step ka nateeja maloom nahi — dobara nahi bheja jayega, chat check karein`);
        } else {
          console.warn(`📦 VPL reminder #${o.id} fail (${e.code || 'error'}): ${e.message} — agli baar dobara koshish`);
          if (['no_extension', 'no_tab', 'not_linked'].includes(e.code)) break;
        }
      }
    }
  } catch (e) {
    console.error('📦 VPL reminders error:', e.message);
  } finally {
    vplRunning = false;
  }
}

// What would be sent today (read-only, sends nothing) — handy for checking.
app.get('/api/vpl-reminders/due', async (req, res) => {
  try {
    const due = (await findVplDue()).filter(o => isAdmin(req.user) || canAccessOrder(req.user, o));
    res.json({ success: true, today: localISODate(), count: due.length,
      orders: due.map(o => ({ id: o.id, name: o.name, shipped_date: o.shipped_date, whatsapp_ok: !!vplNumber(o) })) });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ════════════════════════════════════════════════════════════
//  🛒 PLACE ORDER — one path for BOTH ways of creating an order
//     AI import  → /api/clients/save  ┐
//     Manual form → /api/orders/add   ┴→ checkWhatsAppOrder() → placeOrder()
//  placeOrder: save order + original screenshots → confirm saved →
//  THEN processWhatsAppForOrder(). WhatsApp never looks at the source.
// ════════════════════════════════════════════════════════════
function cleanLines(lines) {
  return (Array.isArray(lines) ? lines : [])
    .map(l => ({ product: String((l && l.product) || '').trim().slice(0, 100), qty: Number(l && l.qty) }))
    .filter(l => l.product && Number.isInteger(l.qty) && l.qty >= 1 && l.qty <= 9999);
}
const saveFail = (res, message, extra) => res.json({ success: false, code: 'validation', message, ...extra });
const cleanAddress = a => String(a || '').replace(/\s+/g, ' ').trim().slice(0, 300);

// Validation shared by AI + manual: original screenshot(s), WhatsApp-ready number, product + quantity.
async function checkWhatsAppOrder({ waIn, phones, lines }) {
  const ids = Array.isArray(waIn.screenshot_ids) ? waIn.screenshot_ids : [];
  if (!ids.length) return { ok: false, message: 'Original order screenshot zaroori hai — screenshot upload karein' };
  if (ids.length > 10 || new Set(ids).size !== ids.length) return { ok: false, message: 'Screenshots ki list sahi nahi' };
  const shots = [];
  for (const sid of ids) {
    if (typeof sid !== 'string' || !SS_ID_RE.test(sid)) return { ok: false, message: 'Screenshot reference sahi nahi' };
    const file = path.join(SS_TMP, sid);
    try {
      const meta = JSON.parse(await fs.promises.readFile(file + '.json', 'utf8'));
      await fs.promises.access(file);
      shots.push({ sid, file, meta });
    } catch (e) {
      console.warn(`[place order] screenshot ${sid} missing:`, e.message);
      return { ok: false, message: 'Original screenshot server par nahi mila (24 ghante se purana?) — dobara upload karein' };
    }
  }
  let wa = waIn.phone ? phoneUtil.normalize(waIn.phone) : phoneUtil.pickWhatsApp(phones);
  if (wa.ok && waIn.phone && !phones.some(p => phoneUtil.sameNumber(p, waIn.phone))) {
    wa = { ok: false, reason: 'WhatsApp number order ke numbers mein se nahi' };
  }
  if (!wa.ok) return { ok: false, message: 'WhatsApp ke liye sahi mobile number chahiye — ' + wa.reason };
  const cleaned = cleanLines(lines);
  if (!cleaned.length) return { ok: false, message: 'Product aur quantity zaroori hain' };
  return { ok: true, shots, wa, lines: cleaned };
}

// Saves the order. With `whatsapp` (from checkWhatsAppOrder) it also attaches the original
// screenshots, freezes the order data, and — only after all of that is committed — starts WhatsApp.
async function placeOrder(row, { address = '', whatsapp = null, owner = null } = {}) {
  if (!owner || !owner.id || !['admin', 'staff'].includes(owner.role)) throw new Error('Order owner missing');   // every new order has an owner
  let orderId = null;
  const moved = [];
  try {
    const r = await dbRun(
      `INSERT INTO orders (name,phone,detail,amount,advance,status,assigned_to,tracking_id,date,month,year,client_id,source,address,workflow_state,wa_phone,
                           created_by_user_id,created_by_role,created_by_name,updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)`,
      [row.name, row.phone, row.detail || '', row.amount, row.advance || 0, row.status || 'Processing', row.assigned_to || 1,
       row.tracking_id || '', row.date, row.month, row.year, null, row.source || 'manual',
       address, whatsapp ? 'ORDER_PLACED' : null, whatsapp ? whatsapp.wa.number : null,
       owner.id, owner.role, String(owner.name || '').slice(0, 120)]);
    orderId = r.lastID;

    // Order Placed Date — stamped by the server at the moment of placement. Failure here never blocks the order.
    try {
      await dbRun(`UPDATE orders SET placed_date=?, shipped_date=? WHERE id=?`,
        [localISODate(), isVplTracking(row.tracking_id) ? localISODate() : null, orderId]);
    } catch (e) { console.warn(`[place order] #${orderId} placed_date save fail:`, e.message); }

    if (whatsapp) {
      const dir = path.join(SS_ROOT, 'orders', String(orderId));
      await fs.promises.mkdir(dir, { recursive: true });
      for (let i = 0; i < whatsapp.shots.length; i++) {
        const { sid, file, meta } = whatsapp.shots[i];
        const dest = path.join(dir, sid);
        await fs.promises.rename(file, dest);          // moved, never copied / re-encoded
        moved.push({ from: file, to: dest });
        const bytes = await fs.promises.readFile(dest);
        if (sha256(bytes) !== meta.sha256) throw new Error(`Screenshot ${i + 1} file kharab hai`);
        // Permanent copy in Supabase Storage. If it fails the whole order is undone (nothing half-saved).
        try { await storage.put(`orders/${orderId}/${sid}`, bytes, meta.mime); }
        catch (se) { throw new Error('Screenshot permanent storage mein save nahi hua: ' + se.message); }
        await dbRun(
          `INSERT INTO order_screenshots (order_id, position, file_name, original_name, mime, bytes, sha256) VALUES (?,?,?,?,?,?,?)`,
          [orderId, i, `orders/${orderId}/${sid}`, meta.name || '', meta.mime, meta.bytes, meta.sha256]);
      }
      const saved = await dbGet(`SELECT * FROM orders WHERE id=?`, [orderId]);
      const snapshot = {
        order_id: orderId,
        order_code: `MA-${String(saved.month + 1).padStart(2, '0')}${String(saved.year).slice(-2)}-${orderId}`,
        source: saved.source,                         // informational only — WhatsApp ignores it
        name: saved.name, phone: saved.phone, wa_phone: whatsapp.wa.number, address,
        lines: whatsapp.lines, detail: saved.detail, amount: Number(saved.amount), advance: Number(saved.advance) || 0,
        tracking_id: saved.tracking_id || '', business: BUSINESS_NAME, saved_at: new Date().toISOString(),
      };
      await dbRun(`UPDATE orders SET wa_snapshot=? WHERE id=?`, [JSON.stringify(snapshot), orderId]);
      whatsapp.shots.forEach(s => fs.promises.unlink(s.file + '.json')
        .catch(e => console.warn('[place order] temp meta cleanup:', e.message)));
    }
  } catch (e) {
    if (orderId) {   // half-saved → undo completely, so nothing is left behind and nothing is sent
      console.error(`[place order] save failed, undoing #${orderId}:`, e.message);
      for (const m of moved.reverse()) await fs.promises.rename(m.to, m.from).catch(x => console.error('[place order] undo move:', x.message));
      await dbRun(`DELETE FROM order_screenshots WHERE order_id=?`, [orderId]).catch(x => console.error('[place order] undo rows:', x.message));
      await dbRun(`DELETE FROM orders WHERE id=?`, [orderId]).catch(x => console.error('[place order] undo order:', x.message));
    }
    throw e;
  }

  // ── ORDER IS SAVED. Nothing below can undo it. ──
  let waStarted = false;
  if (whatsapp) {
    try { waStarted = await waFlow.processWhatsAppForOrder(orderId); }
    catch (e) { console.error(`[WhatsApp] could not start for order #${orderId}:`, e.message); }
  }
  const order = await dbGet(`SELECT o.*, (SELECT COUNT(*) FROM order_screenshots s WHERE s.order_id=o.id) AS screenshot_count
                             FROM orders o WHERE o.id=?`, [orderId]);
  return { order, waStarted };
}

// ── AI IMPORT → PLACE ORDER ──
app.post('/api/clients/save', async (req, res) => {
  try {
    if (!req.body || req.body.mode !== 'client_and_order') return saveFail(res, 'Only Place Order is supported');
    // A cancelled / superseded screenshot extraction must never end up creating an order.
    const exJob = req.body.extraction_job_id;
    if (exJob && extraction.manager.validId(String(exJob)) && extraction.manager.wasCancelled(extractOwner(req), String(exJob))) {
      return saveFail(res, 'This screenshot extraction was cancelled — nothing was saved. Upload the screenshot again or enter the details manually.', { code: 'extraction_cancelled' });
    }
    const waIn = (req.body.whatsapp && typeof req.body.whatsapp === 'object') ? req.body.whatsapp : null;
    const forValidator = { ...req.body };
    delete forValidator.whatsapp;
    const v = ai.validateSavePayload(forValidator);
    if (!v.ok) return saveFail(res, v.errors[0], { errors: v.errors });
    const { source, client, order } = v.value;
    if (!order) return saveFail(res, 'Order details required hain');

    let whatsapp = null;
    if (source === 'ai_screenshot' || waIn) {
      const phones = Array.isArray(req.body.client && req.body.client.phones) ? req.body.client.phones.map(String) : phoneUtil.split(client.phone);
      whatsapp = await checkWhatsAppOrder({ waIn: waIn || {}, phones, lines: req.body.order && req.body.order.lines });
      if (!whatsapp.ok) return saveFail(res, whatsapp.message);
    }

    let assignedTo;
    if (!isAdmin(req.user)) {
      assignedTo = req.user.id;                     // Staff orders belong to / are assigned to the staff member
    } else if (order.assigned_to) {
      const u = await dbGet(`SELECT id FROM users WHERE id=?`, [order.assigned_to]);
      if (!u) return saveFail(res, 'Selected staff member was not found');
      assignedTo = u.id;
    } else {
      const admin = await dbGet(`SELECT id FROM users WHERE role='admin' ORDER BY id ASC LIMIT 1`);
      assignedTo = admin ? admin.id : 1;
    }
    const parts = ai.isoToParts(order.order_date);
    const out = await placeOrder({
      name: client.name, phone: client.phone, detail: order.detail, amount: order.amount, advance: order.advance,
      status: order.status, assigned_to: assignedTo, tracking_id: order.tracking_id,
      date: order.date_label || parts.label, month: parts.month, year: parts.year, source,
    }, { address: cleanAddress(req.body.client && req.body.client.address), whatsapp, owner: ownerOf(req.user) });
    res.json({ success: true, order: out.order, whatsapp: { started: out.waStarted } });
  } catch (e) {
    console.error('[clients/save]', e.stack || e.message);
    res.json({ success: false, code: 'save_failed', message: 'Order could not be saved. WhatsApp was not opened.', detail: e.message });
  }
});

// ════════════════════════════════════════════════════════════
//  💬 WHATSAPP — status, retry, session (QR link)
//  None of these can create an order.
// ════════════════════════════════════════════════════════════
app.get('/api/orders/:id/whatsapp', requireOrderAccess, async (req, res) => {
  try {
    const st = await waFlow.getStatus(req.order.id);
    if (!st) return res.json({ success: false, code: 'not_found', message: 'Order nahi mila' });
    res.json({ success: true, whatsapp: st });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

app.post('/api/orders/:id/whatsapp/retry', requireOrderAccess, async (req, res) => {
  try {
    const out = await waFlow.retry(req.order.id, { standard: !!(req.body && req.body.standard) });
    res.json(out.ok ? { success: true } : { success: false, code: out.code, message: out.message });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

app.post('/api/orders/:id/whatsapp/mark-sent', requireOrderAccess, async (req, res) => {
  try {
    const ok = await waFlow.markSent(req.order.id);
    res.json(ok ? { success: true } : { success: false, message: 'Sirf failed WhatsApp ko "sent" mark kar saktay hain' });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ════════════════════════════════════════════════════════════
//  📤 SEND DISPATCH MESSAGE — Method 1 (WhatsApp click-to-chat)
//  The server prepares the chat number + message from the SAVED order; the browser opens
//  WhatsApp and the person attaches the original image and presses Send. Every route is
//  ownership-checked (requireOrderAccess): Admin → any order, Staff → only their own.
//  Nothing here sends a message, creates an order, or changes the order / courier status.
// ════════════════════════════════════════════════════════════
const DISPATCH_PROBLEMS = {
  no_phone:    'Is order mein customer ka phone number nahi hai.',
  bad_phone:   'Customer ka number WhatsApp ke liye sahi nahi',
  no_tracking: 'Tracking ID abhi save nahi hui — dispatch message tracking ID ke baghair nahi banta.',
  template:    'Dispatch message nahi ban saka',
};
// The number the chat opens for. The number picked at Place Order (wa_phone) is used only while
// it is still one of the order's current numbers — after the phone is edited, the edited one wins.
function dispatchNumber(o) {
  const phones = phoneUtil.split(o.phone || '');
  if (!phones.length) return { ok: false, code: 'no_phone', reason: DISPATCH_PROBLEMS.no_phone };
  let ph = null;
  if (o.wa_phone && phones.some(p => phoneUtil.sameNumber(p, o.wa_phone))) ph = phoneUtil.normalize(o.wa_phone);
  if (!ph || !ph.ok) ph = phoneUtil.pickWhatsApp(phones);
  if (!ph || !ph.ok || !/^\d{8,15}$/.test(String(ph.number || ''))) {
    return { ok: false, code: 'bad_phone', reason: `${DISPATCH_PROBLEMS.bad_phone}${ph && ph.reason ? ' — ' + ph.reason : ''}` };
  }
  return { ok: true, number: String(ph.number), display: ph.display || '+' + ph.number };
}
function dispatchState(o) {
  return {
    status: o.dispatch_status || null, phone: o.dispatch_phone || null,
    opened_at: o.dispatch_opened_at || null, sent_at: o.dispatch_sent_at || null, by_name: o.dispatch_by_name || null,
  };
}

app.get('/api/orders/:id(\\d+)/dispatch', requireOrderAccess, async (req, res) => {
  try {
    const o = req.order;
    const problems = [];
    const num = dispatchNumber(o);
    if (!num.ok) problems.push({ code: num.code, message: num.reason });
    let message = '', orderCode = makeOrderCode(o);
    if (!String(o.tracking_id || '').trim()) problems.push({ code: 'no_tracking', message: DISPATCH_PROBLEMS.no_tracking });
    else {
      try { const m = waFlow.dispatchMessage(o, { business: BUSINESS_NAME }); message = m.text; orderCode = m.order_code; }
      catch (e) { problems.push({ code: 'template', message: `${DISPATCH_PROBLEMS.template}: ${e.message}` }); }
    }
    const shots = await dbAll(`SELECT id, position, original_name, mime, bytes FROM order_screenshots WHERE order_id=? ORDER BY position ASC`, [o.id]);
    res.json({
      success: true,
      dispatch: {
        order_id: o.id, order_code: orderCode, customer: o.name, tracking_id: o.tracking_id || '',
        ready: problems.length === 0, problems,
        phone: num.ok ? { number: num.number, display: num.display } : null,
        message,
        screenshots: shots.map(s => ({
          id: s.id, position: s.position, name: s.original_name || `Screenshot ${s.position + 1}`, mime: s.mime, bytes: s.bytes,
          url: `/api/orders/${o.id}/screenshots/${s.id}/file`,
        })),
        state: dispatchState(o),
        // The automatic sender's result for this order, so nobody sends the same message twice by accident.
        auto: { status: o.wa_status || null, sent_at: o.wa_sent_at || null },
      },
    });
  } catch (e) { console.error('[dispatch]', e.message); res.status(500).json({ success: false, message: 'Dispatch details load nahi huin' }); }
});

// The browser opened the WhatsApp chat. This is NOT "sent" — WhatsApp gives no confirmation.
app.post('/api/orders/:id(\\d+)/dispatch/opened', requireOrderAccess, async (req, res) => {
  try {
    const o = req.order;
    const num = dispatchNumber(o);
    if (!num.ok) return res.status(400).json({ success: false, code: num.code, message: num.reason });
    // Already confirmed as sent → keep 'sent'; only the "opened" time is refreshed.
    await dbRun(`UPDATE orders SET dispatch_status = CASE WHEN dispatch_status = 'sent' THEN 'sent' ELSE 'opened' END,
                   dispatch_phone=?, dispatch_opened_at=CURRENT_TIMESTAMP, dispatch_by_user_id=?, dispatch_by_name=? WHERE id=?`,
      [num.number, req.user.id, String(req.user.name || '').slice(0, 120), o.id]);
    const row = await dbGet(`SELECT * FROM orders WHERE id=?`, [o.id]);
    res.json({ success: true, state: dispatchState(row) });
  } catch (e) { console.error('[dispatch/opened]', e.message); res.status(500).json({ success: false, message: 'Status save nahi hua' }); }
});

// The person confirms they pressed Send in WhatsApp ({sent:true}), or undoes that ({sent:false}).
app.post('/api/orders/:id(\\d+)/dispatch/confirm', requireOrderAccess, async (req, res) => {
  try {
    const o = req.order;
    const sent = !(req.body && req.body.sent === false);
    if (sent) {
      await dbRun(`UPDATE orders SET dispatch_status='sent', dispatch_sent_at=CURRENT_TIMESTAMP, dispatch_by_user_id=?, dispatch_by_name=? WHERE id=?`,
        [req.user.id, String(req.user.name || '').slice(0, 120), o.id]);
    } else {
      await dbRun(`UPDATE orders SET dispatch_status = CASE WHEN dispatch_opened_at IS NULL THEN NULL ELSE 'opened' END, dispatch_sent_at=NULL
                   WHERE id=? AND dispatch_status='sent'`, [o.id]);
    }
    const row = await dbGet(`SELECT * FROM orders WHERE id=?`, [o.id]);
    res.json({ success: true, state: dispatchState(row) });
  } catch (e) { console.error('[dispatch/confirm]', e.message); res.status(500).json({ success: false, message: 'Status save nahi hua' }); }
});

app.get('/api/whatsapp/session', (req, res) => res.json({ success: true, session: waSender.status() }));
app.post('/api/whatsapp/session/start', async (req, res) => {
  try { res.json({ success: true, session: await waSender.start() }); }
  catch (e) { res.json({ success: false, message: e.message }); }
});
// Proves the CRM can drive WhatsApp Web in THIS browser: sends a short text to a number you choose.
app.post('/api/whatsapp/test', async (req, res) => {
  const ph = phoneUtil.normalize(req.body && req.body.phone);
  if (!ph.ok) return res.json({ success: false, code: 'bad_phone', message: ph.reason });
  try { await waSender.sendTest(ph.number); res.json({ success: true, result: { to: ph.display } }); }
  catch (e) {
    console.warn('[WhatsApp] test message failed:', e.code || '', e.message);
    res.json({ success: false, code: e.code || 'error', message: e.message });
  }
});
// ── Bridge for the "MA CRM WhatsApp" browser extension (same browser as the CRM) ──
app.post('/api/wa-bridge/crm-poll', (req, res) => res.json(waSender.crmPoll(req.body || {})));
app.post('/api/wa-bridge/poll', (req, res) => {
  const b = req.body || {};
  res.json({ success: true, job: waSender.poll({ tabId: Number(b.tabId), loggedIn: b.loggedIn, version: String(b.version || '').slice(0, 20) }) });
});
app.post('/api/wa-bridge/jobs/:id/report', async (req, res) => {
  const b = req.body || {};
  try {
    res.json(await waSender.report({ jobId: req.params.id, tabId: Number(b.tabId), step: b.step, state: b.state,
      code: b.code ? String(b.code).slice(0, 40) : null, message: b.message ? String(b.message).slice(0, 300) : null }));
  } catch (e) { console.error('[wa-bridge] report:', e.message); res.json({ ok: false, message: e.message }); }
});
app.get('/api/wa-bridge/jobs/:id/files/:index', (req, res) => {
  const f = waSender.fileFor({ jobId: req.params.id, index: parseInt(req.params.index), tabId: Number(req.query.tabId) });
  if (!f) return res.status(404).json({ success: false, message: 'File not available for this job' });
  res.setHeader('X-File-Name', encodeURIComponent(f.name || 'order-screenshot'));
  res.setHeader('Access-Control-Expose-Headers', 'X-File-Name');
  res.type(f.mime).sendFile(f.path);
});

app.post('/api/whatsapp/session/logout', async (req, res) => {
  try { res.json({ success: true, session: await waSender.logout() }); }
  catch (e) { res.json({ success: false, message: e.message }); }
});

// ── BACKUP (owner only — gate in auth.js) ──────────────────
// Supabase keeps its own backups; SQLite mode writes a consistent copy next to the database.
app.post('/api/backup', async (req, res) => {
  try {
    if (DB.engine === 'postgres')
      return res.json({ success: false, message: 'Database Supabase par hai — backups Supabase dashboard (Database → Backups) mein hotay hain.' });
    const file = `macrm-backup-${new Date().toISOString().replace(/[:.]/g, '-')}.db`;
    fs.mkdirSync(path.join(DATA_DIR, 'backups'), { recursive: true });
    await dbRun(`VACUUM INTO '${path.join(DATA_DIR, 'backups', file).replace(/'/g, "''")}'`);
    res.json({ success: true, backup: { file } });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ── HEALTH CHECK ────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ success: true, message: 'MA CRM Server chal raha hai ✅', version: '1.5' });
});

// ── BODY ERRORS → JSON (e.g. screenshots too large) ─────────
app.use((err, req, res, next) => {
  if (err && err.type === 'entity.too.large') return res.status(413).json({ success: false, code: 'too_large', message: 'Upload too large. Use smaller or fewer screenshots.' });
  if (err && err.type === 'entity.parse.failed') return res.status(400).json({ success: false, code: 'bad_request', message: 'Invalid request data.' });
  next(err);
});

// ── CATCH ALL → index.html ──────────────────────────────────
app.get('*', (req, res) => {
  const indexPath = path.join(__dirname, 'public', 'index.html');
  if (fs.existsSync(indexPath)) {
    res.setHeader('Cache-Control', 'no-cache');
    res.sendFile(indexPath);
  } else {
    res.json({ error: 'index.html nahi mila. public/ folder mein rakho.' });
  }
});

// ── AI SETUP DIAGNOSTICS (printed at start) ─────────────────
function logAiSetup() {
  const nodeMajor = parseInt(process.versions.node, 10);
  console.log('──── 🤖 AI Screenshot Import ────');
  console.log(`   Node.js: v${process.versions.node}${nodeMajor < 18 ? '  ⚠ Node 18+ chahiye (nodejs.org se LTS install karein)' : ''}`);
  console.log(`   Settings file: ${envInfo.file ? envInfo.file + '  (' + path.join(__dirname, envInfo.file) + ')' : 'NAHI MILI'}`);
  envInfo.notes.forEach(n => console.log('   ⚠ ' + n));
  if (!AI_ENABLED) {
    if (!envInfo.file && !envInfo.fromEnvVar) {
      console.log(`   ❌ OFF — is folder mein ".env" file banayein: ${__dirname}`);
      console.log('      Us mein ek line likhein:  GEMINI_API_KEY=aap_ki_key');
    } else if (keyCheck.problem === 'placeholder') {
      console.log('   ❌ OFF — GEMINI_API_KEY mein abhi placeholder likha hai, asli key paste karein');
    } else {
      console.log('   ❌ OFF — GEMINI_API_KEY khali hai. "GEMINI_API_KEY=" ke baad key paste karein');
    }
    console.log('');
    return;
  }
  console.log(`   Key: ${ai.maskKey(GEMINI_API_KEY)}${envInfo.fromEnvVar ? '  (Windows/system environment variable se)' : ''}`);
  console.log(`   Model: ${GEMINI_MODEL}${GEMINI_FALLBACK_MODELS.length ? ' (backup: ' + GEMINI_FALLBACK_MODELS.join(', ') + ')' : ''}`);
  console.log(`   Backup: ${GEMINI_KEYS.length > 1 ? (GEMINI_KEYS.length - 1) + ' extra Gemini key(s)' : 'koi extra Gemini key nahi'}${NVIDIA_API_KEY ? ' + NVIDIA ' + NVIDIA_MODEL : ' (NVIDIA_API_KEY set nahi)'}`);
  if (!GEMINI_API_KEY) { console.log('   ⚠ Main GEMINI_API_KEY nahi hai — sirf backup providers chalenge'); console.log(''); return; }
  console.log('   Key check ho rahi hai...');
  ai.verifyGeminiKey({ apiKey: GEMINI_API_KEY, model: GEMINI_MODEL }).then(h => {
    aiHealth = h;
    const icon = h.state === 'ok' ? '✅' : '❌';
    console.log(`   ${icon} ${h.state === 'ok' ? 'ON — ' : ''}${h.message}`);
    console.log('');
  });
}

// ── WHATSAPP SETUP (printed at start) ───────────────────────
function startWhatsApp() {
  console.log('──── 💬 WhatsApp Order Confirmation ────');
  console.log('   Mode: SAME BROWSER — CRM koi naya browser nahi kholta.');
  console.log('   WhatsApp aap ke apne browser ke logged-in WhatsApp Web tab se jata hai,');
  console.log('   "MA CRM WhatsApp" extension ke zariye. Ek dafa install karein:');
  console.log(`     chrome://extensions (ya edge://extensions) → Developer mode ON → Load unpacked → ${path.join(__dirname, 'whatsapp-extension')}`);
  console.log('');
}

// ── START SERVER ────────────────────────────────────────────
initDB().then(async () => {
  await waFlow.recoverInterrupted();
  cleanScreenshotTmp();
  setInterval(cleanScreenshotTmp, 60 * 60 * 1000).unref();
  // VPL 3-day reminders: check once shortly after start, then keep retrying (only parcels that are
  // still exactly 3 days old) until the browser's WhatsApp Web tab is ready.
  setTimeout(() => runVplReminders('startup'), 15000);
  setInterval(() => runVplReminders('retry'), VPL_RETRY_MS).unref();
  app.listen(PORT, '0.0.0.0', () => {
    console.log('');
    console.log('╔══════════════════════════════════════╗');
    console.log('║     MA CRM Server — Running ✅        ║');
    console.log(`║  Local: http://localhost:${PORT}         ║`);
    console.log('╚══════════════════════════════════════╝');
    console.log('');
    console.log('📂 Public folder mein index.html rakho');
    console.log(`📊 Report Page: /report   | Data: ${DATA_DIR}`);
    console.log('📊 Report API: /api/report/2026/5');
    console.log('🛑 Stop karne ke liye: Ctrl + C');
    console.log('');
    logAiSetup();
    startWhatsApp();
  });
}).catch(err => {
  console.error('❌ Server start nahi hua:', err);
  process.exit(1);
});
